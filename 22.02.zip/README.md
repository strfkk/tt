# TestApp

## About


Application contains login, registration, profile and chat pages.
Data is stored in the device's memory in Coredata.

In order to view all chats sent from a test user or send messages from him, use the login data: 

email: test

password: test 

## Screenshots

<div>
<img src="https://gitlab.com/dmitrytelpov/testApp/-/raw/master/TestAppScreenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202023-01-04%20at%2012.33.51.png" width=30%/>
<img src="https://gitlab.com/dmitrytelpov/testApp/-/raw/master/TestAppScreenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202023-01-04%20at%2012.34.26.png" width=30%/>
<img src="https://gitlab.com/dmitrytelpov/testApp/-/raw/master/TestAppScreenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202023-01-04%20at%2013.07.25.png" width=23%/>
</div>
<div>
<img src="https://gitlab.com/dmitrytelpov/testApp/-/raw/master/TestAppScreenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202023-01-04%20at%2012.51.15.png" width=30%/>
<img src="https://gitlab.com/dmitrytelpov/testApp/-/raw/master/TestAppScreenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202023-01-04%20at%2012.51.24.png" width=30%/>
<img src="https://gitlab.com/dmitrytelpov/testApp/-/raw/master/TestAppScreenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202023-01-04%20at%2012.57.09.png" width=30%/>

</div>
