//
//  Chat+CoreDataClass.swift
//  teatApp
//
//  Created by streifik on 13.12.2022.
//
//

import Foundation
import CoreData

@objc(Chat)
public class Chat: NSManagedObject {

}
