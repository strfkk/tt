//
//  Message1+CoreDataClass.swift
//  teatApp
//
//  Created by streifik on 13.12.2022.
//
//

import Foundation
import CoreData

@objc(Message)

public class Message: NSManagedObject {}
