//
//  UserSingleton.swift
//  testApp
//
//  Created by Dmitry Telpov on 09.02.23.
//

import Foundation

class Settings {
    
    static let shared = Settings()
    
    var user: User?

}
